# NodeJSRestDemo
NodeJS API REST demo app with MongoDB backend
